import heapq
import datetime
from .UtilityList import UtilityList
from .Element import Element
from .Itemset import Itemset
from .PairItemUtility import PairItemUtility


class Algo_TKO:
    """
    #main class of algorithm
    """

    total_time = 0
    hui_count = 0
    # k = 0
    min_utility = 0

    # priority queue of k_itemset = []
    k_itemset = []
    k_itemset = heapq.heapify(k_itemset)

    # hashmap for item to their twu
    item_to_twu = {}

    def __init__(self):
        pass

    # class pair:
    #     """
    #     class to show item and its utility
    #     """
    #
    #     def __init__(self, item=0, utility=0):
    #         self.item = item
    #         self.utility = utility

    def run_algorithm(self, input="", output="", k=0):
        """
        read file, add each item's utility to its twu, create a list with twu>min_utility
        map of utility list for each item, sort items based on their twu
        in second DB Scan
        create utility list of 1 itemset having twu>min_util
        create a list of
        :return:
        """

        # is it right to define these vars here? and with self?
        self.input = input
        self.output = output
        self.k = k

        start_timestamp = datetime.datetime.now()
        self.min_utility = 1

        # First Scan of DataBase
        try:
            input_file = open(input, 'r')
            # split = []
            # items = []
            for line in input_file.readlines():
                if line != '\n' and line[0] != ' ' and line[0] != '@' and line[0] != '#' and line[0] != '%':
                    this_line = line
                    transaction_utility = this_line.split(':')[1]
                    items = [int(i) for i in this_line.split(':')[0].split(' ')]

                    # is it right to use self.item_to_twu here?
                    for item in items:
                        if item in list(self.item_to_twu.keys()) and transaction_utility > self.item_to_twu[item]:
                            # print(item_to_twu[item])
                            self.item_to_twu[item] = transaction_utility
                        if item not in list(self.item_to_twu.keys()):
                            self.item_to_twu[item] = transaction_utility
            # print(self.item_to_twu)
            input_file.close()

        except IOError:
            print('There is a problem finding your file')

        list_items = []
        item_to_utility_list = {}

        for item in self.item_to_twu:
            ulist = UtilityList(item)
            list_items = list_items.append(ulist)
            item_to_utility_list[item] = ulist

        # should we pass self to this method?
        def compare_uls(ul1, ul2):
            if self.item_to_twu[ul1.item] >= self.item_to_twu[ul1.item]:
                return ul1
            else:
                return ul2

        for i in range(0, len(list_items)):
            sorted_ul = True
            for j in range(len(list_items) - i + 1):
                # compare_uls(list_items[j],list_items[j+1])
                if self.item_to_twu[list_items[j].item] > self.item_to_twu[list_items[j + 1].item]:
                    list_items[j], list_items[j + 1] = list_items[j + 1], list_items[j]
                    sorted_ul = False

            if sorted_ul:
                break



        # Second DataBase Scan
        try:
            input_file = open(input, 'r')
            # split = []
            # items = []
            tid = 0

            for line in input_file.readlines():
                if line != '\n' and line[0] != ' ' and line[0] != '@' and line[0] != '#' and line[0] != '%':
                    this_line = line
                    transaction_utility = this_line.split(':')[1]
                    items = [int(i) for i in this_line.split(':')[0].split(' ')]
                    utility_values = [int(i) for i in this_line.split(':')[2].split(' ')]
                    revised_transaction = []

                    # is it right to use self.item_to_twu here?
                    for i in range(0,len(items)):
                        pair = PairItemUtility(items[i],utility_values[i])
                        revised_transaction = revised_transaction.append(pair)

                    remaining_utility = transaction_utility

                    #sort pairs in transaction
                    for i in range(0, len(revised_transaction)):
                        sorted_pair = True
                        for j in range(len(revised_transaction) - i + 1):
                            if self.item_to_twu[revised_transaction[j].item] > self.item_to_twu[revised_transaction[j + 1].item]:
                                revised_transaction[j], revised_transaction[j + 1] = revised_transaction[j + 1], revised_transaction[j]
                                sorted_pair = False

                        if sorted_pair:
                            break

                    for pair in revised_transaction:
                        remaining_utility -= pair.utility
                        utility_list_of_item = UtilityList(pair.item)
                        element = Element(tid,pair.utility,remaining_utility)
                        utility_list_of_item.addElement(element)
                    tid +=1

            # print(self.item_to_twu)
            input_file.close()

        except IOError:
            print('There is a problem finding your file')


        self.search([],None,list_items)
        #memory_usage
        total_time = datetime.datetime.now() - start_timestamp

    def search(self,prefix,pul,uls):
        self.prefix = prefix
        self.pul = pul
        self.uls = uls



    def construct_utility_list(self,p,px,py):
        self.p = p
        self.px = px
        self.py = py

        pxy = UtilityList(py.item)


























