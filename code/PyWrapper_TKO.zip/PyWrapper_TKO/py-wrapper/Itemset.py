class Itemset :

	def __init__(self,item,utility):

		"""

		:param item:
		:param utility:
		"""
		#self.itemset = itemset
		self.utility = utility
		self.item = item


	def compare_to(self):
		pass

	def to_string(self):
		pass