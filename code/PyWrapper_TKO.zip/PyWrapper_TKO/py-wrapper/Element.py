class Element:

	def __init__(self,tid=-1,iutils=0,rutils=0):
		"""
		pass params
		:param tid:
		:param iutils:
		:param rutils:
		"""
		self.tid = tid
		self.iutils = iutils
		self.rutils = rutils

